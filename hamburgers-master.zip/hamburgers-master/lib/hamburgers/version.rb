module Hamburgers
  VERSION = "0.7.0"
end
